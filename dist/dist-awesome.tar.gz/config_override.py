#!/usr/local/bin python3

# -*- coding: utf-8 -*-

__author__ = 'Copper'

'''
生产环境的标准配置
'''

configs = {
	'db' : {
		'host' : '127.0.0.1'
	}
}